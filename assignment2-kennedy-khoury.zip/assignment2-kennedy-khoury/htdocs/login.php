<?php
//login 

//set two variables with default values
$loggedin= false;
$error= false;

//checl if form has been submitted
if($_SERVER['REQUEST_METHOD'] =='POST'){

    //HANDLE FORM
    if(!empty($_POST['email']) && !empty($_POST['password'])){
        if ((strtolower($_POST['email']) == 'khoury.kennedy@ufl.edu') && ($_POST['password'] == 'PaSSworD')){ // correct

            // create cookie
            setcookie('Khoury', 'Kennedy', time()+3600);

            $loggedin=true;

        }else{
            $error = "<p>The submitted email address and password do not match those on file!</p>";
        }
    }else{
        $error ="<p> Please make sure you enter both email and password!</p>";
    }
}

//include header
include('templates/header.php');

//echo error if exits
if($error){
    echo "<p class='error'>$error</p>";
}

//indicate if user logged in
if($loggedin){
    echo "<p> You are now logged in!</p>";
}else{
    echo '<h2>Login Form</h2>
        <form action="login.php" method="post">
        <p><label> Email Adress<input type="email" name="email"</label></p>
        <p><label>Password<input type="password" name="password"</label></p>
        <p><input type="submit" name="submit" value="Log In!"></p>
    </form>';
}


include('templates/footer.php');

?>