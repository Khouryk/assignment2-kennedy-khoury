<?php
//view quotes from he database

    include('templates/header.php');

    echo "<h2> View Quotes </h2>";

    //restict access to admins:

    if(!is_administrator()){
        echo "<h2> Access Denied!</h2>";
        echo "<p class='error'> You do not have permission to access this page. </p>";

        //include footer template
        include('templates/footer.php');

        exit();

    }

    // define quiery

    $query = "SELECT id, quote, source, favorite FROM quotes ORDER BY date_entered DESC";

    //run query
    if($result = mysqli_query($dbc, $query)){

        //retreieve the returne records:
        while($row = mysqli_fetch_array($result)){

            //echo quote
            echo "<div><blockquote>{$row['quote']}</blockquote>-{$row['source']}\n";

            //is this a fav

            if($row['favorite']== 1){
                echo "<strong> Favorite!</strong>";
            }
        //add admin links

        echo "<p> Quote Admin: <a href =\"edit_quote.php?id={$row['id']}\">Edit</a>
            <a href=\"delete_quote.php?id={$row['id']}\">Delete</a></p></div>";
        }//while loop end
    }else{
        echo "<p class='error'>could not retrieve the data because: " . mysqli_error($dbc) . "</p>";
        echo "<p> The query being run was: " . $query . "</p>";
    }// end of query if statement

    mysqli_close($dbc);

    include('templates/footer.php');

    ?>
    