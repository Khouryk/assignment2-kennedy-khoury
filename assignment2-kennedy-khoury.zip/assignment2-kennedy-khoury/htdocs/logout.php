<?php
//logout page, destorys cookies

//destory the cookeie
if(isset($_COOKIE['Khoury'])){
    setcookie('Khoury', FALSE, time()-300);
}

//include header
include('templates/header.php');

//echo message
echo "<p> You are now logged out!</p>";

//include footer
include('templates/footer.php');


?>