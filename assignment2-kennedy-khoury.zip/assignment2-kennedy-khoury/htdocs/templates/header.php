<?php
//include the functions

include('includes/functions.php'); ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf=8">
        <link rel="stylesheet" media="all" href="css/style.css"/>
        <title> Assignment 2 Quotes </title>
</head>

<body>
    <div id="container">
        <h1 a href="index.php">My Site of Quotes</a></h1>

        <!--content-->


