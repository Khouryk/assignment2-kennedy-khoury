<?php
//display gen admin links
if((is_administrator()) || (isset($loggedin)&& $loggedin)){
    //create the links

    echo '<hr><h3>Site Admin</h3>
    <p><a href="add_quote.php"> Add Quote</a> | <a href="view_quotes.php">View All Quotes</a> | <a href="logout.php">Logout</a></p>';

}

?>
</div> <!--container-->

<footer id = "footer">Content &copy; <?php echo date ('Y'); ?> </footer>
</body>
</html>




