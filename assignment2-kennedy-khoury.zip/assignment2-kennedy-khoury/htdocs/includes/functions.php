<?php
/*===================================
function checks if user is an admin
takes two optional values
returns boolean value

==================================*/

function is_administrator($name = 'Khoury', $value ='Kennedy'){
    // check for cookie and its value

    if(isset($_COOKIE[$name])&& ($_COOKIE[$name]==$value)){
        return true;
    }else{
        return false;
    }
}
//connect variable
$dbc = mysqli_connect('localhost','root','root','assignment2-database');

?>